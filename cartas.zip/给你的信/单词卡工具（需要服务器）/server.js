// server.js
// Backend minimalista con Express para estudiar vocabulario.
// Actualizado para usar la API de Groq con extracción robusta de JSON.

require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Variables de entorno para Groq
const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_MODEL = process.env.GROQ_MODEL || 'llama-3.1-8b-instant';
const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

/**
 * Construye los mensajes que se envian a la IA. 
 * Se le pide responder SOLO con un objeto JSON valido con claves fijas.
 */
function buildMessages(text) {
  return [
    {
      role: 'system',
      content:
        'Eres un tutor de inglés sumamente cálido, paciente y experto. Tu misión es ayudar a una hablante nativa de chino mandarín a estudiar. ' +
        'El usuario te enviará una palabra, una frase o un párrafo en inglés. ' +
        'Responde ÚNICAMENTE con un objeto JSON válido, con exactamente estas claves:\n' +
        '{\n' +
        '  "text_en": "la palabra, frase o párrafo original en inglés",\n' +
        '  "phonetics": "transcripción fonética (IPA) si es una palabra, o vacío si es un párrafo",\n' +
        '  "translation_zh": "traducción directa y natural al chino",\n' +
        '  "explanation_zh": "explicación clara del significado, uso o gramática, en chino",\n' +
        '  "example_en": "una oración natural de ejemplo (si el input fue una palabra) o una frase de respuesta sugerida (si fue un párrafo)",\n' +
        '  "example_zh": "traducción al chino del ejemplo anterior",\n' +
        '  "extra_notes": "mnemotecnia y sinónimos (si es palabra), o vocabulario clave extraído (si es un párrafo), explicado en chino",\n' +
        '  "encouragement_zh": "un mensaje corto, muy cálido y motivador en chino para animarla a seguir aprendiendo"\n' +
        '}\n' +
        'No incluyas ninguna clave adicional ni texto fuera del JSON.\n' +
        'REGLAS CRÍTICAS:\n' +
        '1. Usa exclusivamente comillas dobles (") para estructurar las claves del JSON.\n' +
        '2. NUNCA uses comillas dobles, simples ni tipográficas dentro del contenido de tus respuestas. Si necesitas resaltar un objeto o palabra, usa EXCLUSIVAMENTE los corchetes chinos 【 y 】.'},
    { role: 'user', content: `Texto a analizar: ${text}` },
  ];
}

const REQUIRED_KEYS = [
  'text_en',
  'phonetics',
  'translation_zh',
  'explanation_zh',
  'example_en',
  'example_zh',
  'extra_notes',
  'encouragement_zh',
];

app.post('/api/lookup', async (req, res) => {
  const rawInput = req.body.text || req.body.word;
  const text = (rawInput ? String(rawInput) : '').trim();

  if (!text) {
    return res.status(400).json({ error: 'empty_input', message: 'Escribe una palabra o texto para buscar.' });
  }
  
  if (text.length > 600) {
    return res.status(400).json({ error: 'text_too_long', message: 'El texto es demasiado largo (máximo 600 caracteres).' });
  }
  
  if (!GROQ_API_KEY) {
    return res.status(500).json({ error: 'missing_api_key', message: 'Falta configurar GROQ_API_KEY.' });
  }

  const MAX_RETRIES = 3;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      console.log(`Intento ${attempt} procesando: "${text.substring(0, 20)}..."`);
      
      const upstream = await fetch(GROQ_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${GROQ_API_KEY}`,
        },
        body: JSON.stringify({
          model: GROQ_MODEL,
          messages: buildMessages(text),
          temperature: 0.4,
          stream: false,
        }),
      });

      if (!upstream.ok) throw new Error(`Error de API: status ${upstream.status}`);

      const data = await upstream.json();
      let raw = data?.choices?.[0]?.message?.content || '';

      // 1. Filtro Anti-Markdown: Limpia el formato de código si la IA lo inyecta
      raw = raw.replace(/```json/gi, '').replace(/```/g, '').trim();

      // 2. Aislamiento Matemático del Objeto
      const firstBrace = raw.indexOf('{');
      const lastBrace = raw.lastIndexOf('}');
      
      if (firstBrace === -1 || lastBrace === -1) {
        throw new Error('La IA devolvió texto plano sin formato JSON.');
      }
      
      // 3. Extracción y limpieza final
      let cleanJson = raw.substring(firstBrace, lastBrace + 1);
      cleanJson = cleanJson.replace(/[“”]/g, "'");
      
      // 4. Parseo seguro
      const parsed = JSON.parse(cleanJson);
      
      const missing = REQUIRED_KEYS.filter((key) => !(key in parsed) || parsed[key] === null);
      if (missing.length > 0) throw new Error(`JSON incompleto. Faltan: ${missing.join(', ')}`);

      return res.json(parsed);

    } catch (err) {
      console.error(`Fallo en intento ${attempt} para "${text.substring(0, 20)}...": ${err.message}`);
      
      if (attempt === MAX_RETRIES) {
        return res.status(502).json({
          error: 'upstream_error',
          message: 'La red está un poco inestable, intenta de nuevo.',
        });
      }
      
      await new Promise(resolve => setTimeout(resolve, 2000 * attempt));
    }
  }
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});